#!/bin/bash

# Colores para los mensajes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Función para mostrar mensajes
print_message() {
    echo -e "${GREEN}[*]${NC} $1"
}

print_error() {
    echo -e "${RED}[!]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

# Configuración del paquete
PACKAGE_NAME="videogenerator"
PACKAGE_VERSION="1.1"
ARCHITECTURE="amd64"
MAINTAINER="Wamphyre <info@wamphyre.com>"
DESCRIPTION="Generador de videos musicales con imagen estática"

# Verificar dependencias necesarias
print_message "Verificando dependencias..."

dependencies=("python3-pip" "python3-dev" "dpkg" "fakeroot" "ffmpeg" "vainfo" "mesa-va-drivers" "libva-drm2" "libva2" "python3-tk" "python3-pil.imagetk")
missing_deps=()

for dep in "${dependencies[@]}"; do
    if ! dpkg -l | grep -q "^ii  $dep "; then
        missing_deps+=("$dep")
    fi
done

if [ ${#missing_deps[@]} -ne 0 ]; then
    print_warning "Faltan las siguientes dependencias: ${missing_deps[*]}"
    print_message "Instalando dependencias..."
    sudo apt-get update
    sudo apt-get install -y "${missing_deps[@]}"
fi

# Instalar PyInstaller si no está instalado
if ! pip3 list | grep -q "pyinstaller"; then
    print_message "Instalando PyInstaller..."
    pip3 install pyinstaller
fi

# Asegurarnos de que podemos usar PyInstaller
export PATH="$HOME/.local/bin:$PATH"

# Verificar que PyInstaller está disponible
if ! command -v pyinstaller &> /dev/null; then
    print_error "No se puede encontrar PyInstaller. Intentando instalación alternativa..."
    sudo pip3 install pyinstaller
    if ! command -v pyinstaller &> /dev/null; then
        print_error "Error: No se pudo instalar PyInstaller"
        exit 1
    fi
fi

# Limpiar directorios anteriores
print_message "Limpiando directorios anteriores..."
rm -rf build dist __pycache__ ${PACKAGE_NAME}_${PACKAGE_VERSION}

# Crear ejecutable con PyInstaller
print_message "Creando ejecutable con PyInstaller..."
python3 -m PyInstaller --noconfirm \
                      --onefile \
                      --windowed \
                      --add-data "icon.png:." \
                      --icon=icon.png \
                      --name ${PACKAGE_NAME} \
                      videogenerator.py

if [ ! -f "dist/${PACKAGE_NAME}" ]; then
    print_error "Error al crear el ejecutable"
    exit 1
fi

print_message "Ejecutable creado correctamente"

# Crear estructura del paquete DEB
print_message "Creando estructura del paquete DEB..."
mkdir -p ${PACKAGE_NAME}_${PACKAGE_VERSION}/DEBIAN
mkdir -p ${PACKAGE_NAME}_${PACKAGE_VERSION}/usr/bin
mkdir -p ${PACKAGE_NAME}_${PACKAGE_VERSION}/usr/share/applications
mkdir -p ${PACKAGE_NAME}_${PACKAGE_VERSION}/usr/share/icons/hicolor/128x128/apps

# Crear archivo control
print_message "Creando archivo control..."
cat > ${PACKAGE_NAME}_${PACKAGE_VERSION}/DEBIAN/control << EOF
Package: ${PACKAGE_NAME}
Version: ${PACKAGE_VERSION}
Architecture: ${ARCHITECTURE}
Maintainer: ${MAINTAINER}
Depends: ffmpeg, vainfo, mesa-va-drivers, libva-drm2, libva2, python3-tk, python3-pil.imagetk
Priority: optional
Description: ${DESCRIPTION}
 VideoGenerator es una aplicación que crea videos musicales
 combinando archivos de audio con una imagen estática.
 Optimizado para Linux y soporta aceleración por hardware AMD.
EOF

# Copiar archivos
print_message "Copiando archivos..."
cp dist/${PACKAGE_NAME} ${PACKAGE_NAME}_${PACKAGE_VERSION}/usr/bin/
cp icon.png ${PACKAGE_NAME}_${PACKAGE_VERSION}/usr/share/icons/hicolor/128x128/apps/${PACKAGE_NAME}.png

# Crear archivo .desktop
print_message "Creando archivo .desktop..."
cat > ${PACKAGE_NAME}_${PACKAGE_VERSION}/usr/share/applications/${PACKAGE_NAME}.desktop << EOF
[Desktop Entry]
Name=VideoGenerator
Comment=Generador de videos musicales
Exec=${PACKAGE_NAME}
Icon=${PACKAGE_NAME}
Terminal=false
Type=Application
Categories=AudioVideo;Audio;Video;
Keywords=video;audio;music;
EOF

# Establecer permisos
print_message "Estableciendo permisos..."
find ${PACKAGE_NAME}_${PACKAGE_VERSION} -type d -exec chmod 755 {} \;
find ${PACKAGE_NAME}_${PACKAGE_VERSION} -type f -exec chmod 644 {} \;
chmod 755 ${PACKAGE_NAME}_${PACKAGE_VERSION}/usr/bin/${PACKAGE_NAME}

# Crear el paquete DEB
print_message "Creando paquete DEB..."
dpkg-deb --build ${PACKAGE_NAME}_${PACKAGE_VERSION}

if [ $? -eq 0 ]; then
    print_message "Paquete DEB creado correctamente: ${PACKAGE_NAME}_${PACKAGE_VERSION}.deb"
    
    # Mostrar información del paquete
    print_message "Información del paquete:"
    dpkg -I ${PACKAGE_NAME}_${PACKAGE_VERSION}.deb
    
    # Limpiar archivos temporales
    print_message "Limpiando archivos temporales..."
    rm -rf build dist __pycache__ ${PACKAGE_NAME}_${PACKAGE_VERSION}
    
    print_message "Proceso completado con éxito"
    print_message "Para instalar el paquete:"
    echo "    sudo dpkg -i ${PACKAGE_NAME}_${PACKAGE_VERSION}.deb"
    echo "    sudo apt-get install -f  # Si hay dependencias faltantes"
else
    print_error "Error al crear el paquete DEB"
    exit 1
fi