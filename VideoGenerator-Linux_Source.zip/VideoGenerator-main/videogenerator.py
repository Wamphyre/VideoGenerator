import os
import sys
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
from PIL import Image, ImageTk
import re
import threading
import time

class GPUDetector:
    @staticmethod
    def check_encoders():
        try:
            # Verificar encoders disponibles
            ffmpeg_result = subprocess.run(
                ['ffmpeg', '-encoders'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            encoders = ffmpeg_result.stdout.lower()
            
            has_h264 = 'h264_vaapi' in encoders
            has_hevc = 'hevc_vaapi' in encoders
            
            # Verificar VAAPI y AMD
            vainfo_result = subprocess.run(['vainfo'], 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE, 
                text=True
            )
            has_amd = vainfo_result.returncode == 0 and 'AMD' in vainfo_result.stdout
            
            return {
                'h264': has_h264 and has_amd,
                'hevc': has_hevc and has_amd
            }
        except:
            return {'h264': False, 'hevc': False}

    @staticmethod
    def check_vaapi():
        try:
            encoders = GPUDetector.check_encoders()
            return encoders['h264'] or encoders['hevc']
        except:
            return False

def obtener_numero_pista(nombre_archivo):
    # Primero intenta encontrar números al inicio del nombre
    match = re.search(r'^(\d+)', os.path.splitext(nombre_archivo)[0])
    if match:
        return int(match.group(1))
    # Si no hay número al inicio, busca cualquier número
    match = re.search(r'(\d+)', os.path.splitext(nombre_archivo)[0])
    if match:
        return int(match.group(1))
    # Si no hay números, devuelve el nombre para orden alfabético
    return nombre_archivo

class VideoEncoder:
    def __init__(self):
        self.cpu_count = os.cpu_count() or 1
        self.gpu_detector = GPUDetector()
        self.encoders = self.gpu_detector.check_encoders()
        self.has_gpu = self.gpu_detector.check_vaapi()

    def get_image_dimensions(self, image_path):
        probe_cmd = [
            'ffprobe', '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height',
            '-of', 'csv=p=0',
            image_path
        ]
        result = subprocess.run(probe_cmd, capture_output=True, text=True)
        if result.returncode == 0:
            width, height = map(int, result.stdout.strip().split(','))
            return width, height
        return 1920, 1080  # valores por defecto

    def calculate_scaling_dimensions(self, width, height):
        if width/height > 16/9:  # imagen más ancha que 16:9
            new_width = 1920
            new_height = int(1920 * height / width)
        else:  # imagen más alta o igual que 16:9
            new_height = 1080
            new_width = int(1080 * width / height)
        
        x_offset = (1920 - new_width) // 2
        y_offset = (1080 - new_height) // 2
        
        return new_width, new_height, x_offset, y_offset

    def get_gpu_command(self, image_path, audio_files, output_path, high_quality=True):
        # Obtener dimensiones y calcular escalado
        width, height = self.get_image_dimensions(image_path)
        new_width, new_height, x_offset, y_offset = self.calculate_scaling_dimensions(width, height)

        # Calcular duración total del audio
        total_duration = 0
        for audio_file in audio_files:
            result = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', 
                                   '-of', 'default=noprint_wrappers=1:nokey=1', audio_file], 
                                  capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip():
                total_duration += float(result.stdout)

        # Construir filtros para el procesamiento en CPU antes de la codificación GPU
        vf_filters = [
            f'scale={new_width}:{new_height}',
            f'pad=1920:1080:{x_offset}:{y_offset}:color=black',
            'fade=t=in:st=0:d=4',
            f'fade=t=out:st={total_duration-4}:d=4',
            'format=nv12|vaapi,hwupload'
        ]

        # Construir el filtro complex para audio
        audio_inputs = []
        filter_complex = []
        for i, audio_file in enumerate(audio_files):
            audio_inputs.extend(['-i', audio_file])
            filter_complex.append(f'[{i+1}:a]')

        filter_complex = ''.join(filter_complex) + f'concat=n={len(audio_files)}:v=0:a=1[aout]'

        # Comando base
        command = [
            'ffmpeg',
            '-hide_banner',
            '-y',
            '-loop', '1',
            '-i', image_path
        ]
        
        # Añadir inputs de audio
        command.extend(audio_inputs)

        # Configuración de hardware
        command.extend([
            '-vaapi_device', '/dev/dri/renderD128',
            '-vf', ','.join(vf_filters)
        ])

        # Añadir filtro complex para audio
        command.extend([
            '-filter_complex', filter_complex,
            '-map', '0:v',
            '-map', '[aout]'
        ])

        # Configuración de codificación
        if self.encoders['hevc']:
            command.extend([
                '-c:v', 'hevc_vaapi',
                '-qp', '18' if high_quality else '23',
                '-profile:v', 'main'
            ])
        else:
            command.extend([
                '-c:v', 'h264_vaapi',
                '-qp', '18' if high_quality else '23',
                '-profile:v', 'high'
            ])

        # Configuración de audio y salida
        command.extend([
            '-c:a', 'aac',
            '-b:a', '320k',
            '-t', str(total_duration),
            output_path
        ])

        return command

    def get_cpu_command(self, image_path, audio_files, output_path, high_quality=True):
        # Obtener dimensiones y calcular escalado
        width, height = self.get_image_dimensions(image_path)
        new_width, new_height, x_offset, y_offset = self.calculate_scaling_dimensions(width, height)

        # Calcular duración total del audio
        total_duration = 0
        for audio_file in audio_files:
            result = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', 
                                   '-of', 'default=noprint_wrappers=1:nokey=1', audio_file], 
                                  capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip():
                total_duration += float(result.stdout)

        # Construir filtros para CPU
        vf_filters = [
            f'scale={new_width}:{new_height}',
            f'pad=1920:1080:{x_offset}:{y_offset}:color=black',
            'fade=t=in:st=0:d=4',
            f'fade=t=out:st={total_duration-4}:d=4'
        ]

        audio_inputs = []
        filter_complex = []
        for i, audio_file in enumerate(audio_files):
            audio_inputs.extend(['-i', audio_file])
            filter_complex.append(f'[{i+1}:a]')

        filter_complex = ''.join(filter_complex) + f'concat=n={len(audio_files)}:v=0:a=1[aout]'

        command = [
            'ffmpeg',
            '-hide_banner',
            '-y',
            '-loop', '1',
            '-i', image_path
        ]
        
        command.extend(audio_inputs)

        command.extend([
            '-vf', ','.join(vf_filters),
            '-filter_complex', filter_complex,
            '-map', '0:v',
            '-map', '[aout]',
            '-c:v', 'libx264',
            '-preset', 'slow' if high_quality else 'medium',
            '-crf', '18' if high_quality else '23',
            '-profile:v', 'high',
            '-tune', 'stillimage',
            '-movflags', '+faststart',
            '-pix_fmt', 'yuv420p',
            '-c:a', 'aac',
            '-b:a', '320k',
            '-t', str(total_duration),
            output_path
        ])

        return command

    def create_video(self, image_path, audio_dir, output_path, high_quality=True, force_cpu=False, progress_callback=None):
        # Obtener lista de archivos de audio
        audio_files = []
        for file in os.listdir(audio_dir):
            if file.lower().endswith(('.mp3', '.wav', '.ogg', '.flac', '.aac', '.m4a', '.wma')):
                audio_files.append(file)

        # Ordenar archivos por número de pista
        audio_files.sort(key=obtener_numero_pista)
        
        # Convertir a rutas completas después de ordenar
        audio_files = [os.path.join(audio_dir, file) for file in audio_files]

        if not audio_files:
            raise Exception("No se encontraron archivos de audio")

        if progress_callback:
            progress_callback("Orden de las pistas:")
            for i, file in enumerate(audio_files, 1):
                progress_callback(f"  {i}. {os.path.basename(file)}")

        # Seleccionar comando apropiado
        if self.has_gpu and not force_cpu:
            command = self.get_gpu_command(image_path, audio_files, output_path, high_quality)
        else:
            command = self.get_cpu_command(image_path, audio_files, output_path, high_quality)

        # Ejecutar comando
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )

        # Procesar la salida en tiempo real
        while True:
            output = process.stderr.readline()
            if output == '' and process.poll() is not None:
                break
            if output and progress_callback:
                progress_callback(output.strip())

        # Verificar si hubo error
        if process.returncode != 0:
            raise Exception(f"Error en FFmpeg: {process.stderr.read()}")

        return True

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.master.title("VideoGenerator v1.1 (Linux)")
        self.master.geometry("900x600")
        self.master.resizable(False, False)
        
        try:
            icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon.png')
            if os.path.exists(icon_path):
                icon_image = Image.open(icon_path)
                icon_photo = ImageTk.PhotoImage(icon_image)
                self.master.wm_iconphoto(True, icon_photo)
        except Exception as e:
            print(f"No se pudo cargar el icono: {e}")
        
        self.pack(fill=tk.BOTH, expand=True)
        self.high_quality = tk.BooleanVar(value=True)
        self.force_cpu = tk.BooleanVar(value=False)
        
        # Detectar GPU y codecs disponibles
        self.gpu_detector = GPUDetector()
        self.encoders = self.gpu_detector.check_encoders()
        self.has_gpu = self.gpu_detector.check_vaapi()
        
        self.create_widgets()
        
        if self.has_gpu:
            codecs = []
            if self.encoders['h264']:
                codecs.append('H.264')
            if self.encoders['hevc']:
                codecs.append('HEVC')
            self.add_info(f"GPU AMD detectada: Codecs disponibles: {', '.join(codecs)}")
        else:
            self.add_info("No se detectó GPU AMD: Se usará codificación por CPU")
            self.force_cpu.set(True)

    def create_widgets(self):
        main_frame = ttk.Frame(self)
        main_frame.pack(padx=20, pady=20, fill=tk.BOTH, expand=True)

        style = ttk.Style()
        style.configure('TButton', font=('Arial', 12))
        style.configure('Salir.TButton', 
                       font=('Arial', 12, 'bold'),
                       padding=(0, 0))

        selection_frame = ttk.Frame(main_frame)
        selection_frame.pack(fill=tk.X, pady=10)

        self.directorio_btn = ttk.Button(selection_frame, text="Seleccionar directorio de audio", 
                                       command=self.seleccionar_directorio)
        self.directorio_btn.grid(row=0, column=0, padx=5, pady=5, sticky="ew")

        self.imagen_btn = ttk.Button(selection_frame, text="Seleccionar imagen", 
                                   command=self.seleccionar_imagen)
        self.imagen_btn.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        self.salida_btn = ttk.Button(selection_frame, text="Seleccionar directorio de salida", 
                                   command=self.seleccionar_directorio_salida)
        self.salida_btn.grid(row=1, column=0, padx=5, pady=5, sticky="ew")

        self.nombre_btn = ttk.Button(selection_frame, text="Especificar nombre del archivo", 
                                   command=self.especificar_nombre_archivo)
        self.nombre_btn.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        selection_frame.grid_columnconfigure(0, weight=1)
        selection_frame.grid_columnconfigure(1, weight=1)

        # Frame para opciones de codificación
        encoding_frame = ttk.Frame(main_frame)
        encoding_frame.pack(fill=tk.X, pady=5)

        options_frame = ttk.Frame(encoding_frame)
        options_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.quality_check = ttk.Checkbutton(options_frame, 
                                           text="Alta calidad (más lento)",
                                           variable=self.high_quality)
        self.quality_check.pack(side=tk.LEFT, padx=5)

        if self.has_gpu:
            self.cpu_check = ttk.Checkbutton(options_frame, 
                                           text="Forzar uso de CPU",
                                           variable=self.force_cpu)
            self.cpu_check.pack(side=tk.LEFT, padx=5)

        self.generar_btn = ttk.Button(encoding_frame, text="Generar video", 
                                    command=self.generar_video)
        self.generar_btn.pack(side=tk.RIGHT, padx=5)

        self.progress = ttk.Progressbar(main_frame, orient="horizontal", 
                                      length=300, mode="determinate")
        self.progress.pack(fill=tk.X, pady=10)

        log_label = ttk.Label(main_frame, text="Log de progreso:", font=('Arial', 10, 'bold'))
        log_label.pack(anchor='w', pady=(10,0))

        info_frame = ttk.Frame(main_frame)
        info_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.info_text = tk.Text(info_frame, height=15, wrap=tk.WORD)
        self.info_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = ttk.Scrollbar(info_frame, orient="vertical", 
                                command=self.info_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.info_text.configure(yscrollcommand=scrollbar.set)

        # Frame para el botón SALIR
        quit_frame = ttk.Frame(main_frame)
        quit_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=0)

        self.quit = ttk.Button(quit_frame, 
                             text="SALIR",
                             style='Salir.TButton',
                             command=self.master.destroy)
        self.quit.pack(expand=True, ipadx=50, ipady=15)

    def add_info(self, message):
        self.info_text.insert(tk.END, str(message) + "\n")
        self.info_text.see(tk.END)
        self.info_text.update()

    def update_progress(self, value):
        self.progress['value'] = value
        self.progress.update()

    def parse_progress(self, line):
        try:
            if "time=" in line:
                time_str = line.split("time=")[1].split()[0]
                if ":" in time_str:
                    h, m, s = time_str.split(":")
                    current_time = float(h) * 3600 + float(m) * 60 + float(s)
                    if hasattr(self, 'total_duration') and self.total_duration > 0:
                        progress = (current_time / self.total_duration) * 100
                        self.update_progress(min(100, progress))
        except:
            pass

    def seleccionar_directorio(self):
        self.directorio_audio = filedialog.askdirectory()
        if self.directorio_audio:
            self.add_info(f"Directorio de audio seleccionado: {self.directorio_audio}")
            # Mostrar archivos encontrados y su orden
            archivos = [f for f in os.listdir(self.directorio_audio) 
                       if f.lower().endswith(('.mp3','.wav','.ogg','.flac','.aac','.m4a','.wma'))]
            archivos.sort(key=obtener_numero_pista)
            if archivos:
                self.add_info("Pistas encontradas (en orden de reproducción):")
                for i, archivo in enumerate(archivos, 1):
                    self.add_info(f"  {i}. {archivo}")
            else:
                self.add_info("No se encontraron archivos de audio en el directorio")

    def seleccionar_imagen(self):
        self.imagen_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.png")])
        if self.imagen_path:
            self.add_info(f"Imagen seleccionada: {self.imagen_path}")

    def seleccionar_directorio_salida(self):
        self.directorio_salida = filedialog.askdirectory()
        if self.directorio_salida:
            self.add_info(f"Directorio de salida seleccionado: {self.directorio_salida}")

    def especificar_nombre_archivo(self):
        self.nombre_archivo = simpledialog.askstring("Nombre del archivo", 
                                                   "Ingrese el nombre del archivo de video (sin extensión):")
        if self.nombre_archivo:
            self.nombre_archivo = self.nombre_archivo.strip()
            if not self.nombre_archivo.endswith('.mp4'):
                self.nombre_archivo += '.mp4'
            self.add_info(f"Nombre del archivo especificado: {self.nombre_archivo}")

    def calcular_duracion_total(self):
        total_duration = 0
        for file in os.listdir(self.directorio_audio):
            if file.lower().endswith(('.mp3', '.wav', '.ogg', '.flac', '.aac', '.m4a', '.wma')):
                file_path = os.path.join(self.directorio_audio, file)
                result = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', 
                                       '-of', 'default=noprint_wrappers=1:nokey=1', file_path], 
                                      capture_output=True, text=True)
                if result.returncode == 0 and result.stdout.strip():
                    total_duration += float(result.stdout)
        return total_duration

    def generar_video(self):
        if not hasattr(self, 'directorio_audio') or not hasattr(self, 'imagen_path') \
           or not hasattr(self, 'directorio_salida'):
            messagebox.showerror("Error", 
                               "Por favor, selecciona el directorio de audio, la imagen y el directorio de salida")
            return

        if not hasattr(self, 'nombre_archivo'):
            self.nombre_archivo = "video_musical.mp4"

        output_path = os.path.join(self.directorio_salida, self.nombre_archivo)
        
        counter = 1
        nombre_base, extension = os.path.splitext(self.nombre_archivo)
        while os.path.exists(output_path):
            output_path = os.path.join(self.directorio_salida, f"{nombre_base}_{counter}{extension}")
            counter += 1

        self.add_info("Iniciando generación del video...")
        if self.has_gpu and not self.force_cpu.get():
            codec_usado = 'HEVC' if self.encoders['hevc'] else 'H.264'
            self.add_info(f"Usando aceleración por hardware GPU con codec {codec_usado}")
        else:
            self.add_info("Usando codificación por CPU")
            
        self.progress['value'] = 0
        self.total_duration = self.calcular_duracion_total()
        
        # Deshabilitar todos los controles durante la generación
        for widget in [self.generar_btn, self.directorio_btn, self.imagen_btn, 
                      self.salida_btn, self.nombre_btn, self.quality_check, 
                      self.quit]:
            widget['state'] = 'disabled'
        if self.has_gpu:
            self.cpu_check['state'] = 'disabled'
        
        threading.Thread(target=self.generar_video_thread, 
                       args=(output_path,), daemon=True).start()

    def generar_video_thread(self, output_path):
        try:
            encoder = VideoEncoder()
            
            def progress_callback(message):
                self.master.after(0, self.add_info, message)
                self.master.after(0, self.parse_progress, message)

            encoder.create_video(
                self.imagen_path,
                self.directorio_audio,
                output_path,
                self.high_quality.get(),
                self.force_cpu.get(),
                progress_callback
            )
            
            self.master.after(0, self.video_generado_exitosamente, output_path)
        except Exception as e:
            self.master.after(0, self.mostrar_error, str(e))
        finally:
            self.master.after(0, self.habilitar_botones)

    def video_generado_exitosamente(self, output_path):
        self.add_info(f"Video generado correctamente: {output_path}")
        messagebox.showinfo("Éxito", f"Video generado correctamente: {output_path}")

    def mostrar_error(self, mensaje_error):
        self.add_info(f"Error al generar el video: {mensaje_error}")
        messagebox.showerror("Error", f"Error al generar el video: {mensaje_error}")

    def habilitar_botones(self):
        for widget in [self.generar_btn, self.directorio_btn, self.imagen_btn, 
                      self.salida_btn, self.nombre_btn, self.quality_check, 
                      self.quit]:
            widget['state'] = 'normal'
        if self.has_gpu:
            self.cpu_check['state'] = 'normal'

if __name__ == "__main__":
    root = tk.Tk()
    app = Application(master=root)
    app.mainloop()