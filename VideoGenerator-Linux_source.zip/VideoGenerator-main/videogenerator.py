import os
import sys
import subprocess
from moviepy.editor import *
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
from PIL import Image, ImageTk
import re
import numpy as np
import psutil
import io
import threading
import time

class StdoutRedirector(io.StringIO):
    def __init__(self, write_func, progress_func):
        self.write_func = write_func
        self.progress_func = progress_func
        super().__init__()

    def write(self, string):
        self.write_func(string.strip())
        if string.startswith('t:'):
            try:
                progress = float(string.split()[1])
                self.progress_func(progress)
            except:
                pass

class GPUDetector:
    @staticmethod
    def check_encoders():
        try:
            # Verificar encoders disponibles
            ffmpeg_result = subprocess.run(
                ['ffmpeg', '-encoders'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            encoders = ffmpeg_result.stdout.lower()
            
            has_h264 = 'h264_vaapi' in encoders
            has_hevc = 'hevc_vaapi' in encoders
            
            # Verificar VAAPI y AMD
            vainfo_result = subprocess.run(['vainfo'], 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE, 
                text=True
            )
            has_amd = vainfo_result.returncode == 0 and 'AMD' in vainfo_result.stdout
            
            return {
                'h264': has_h264 and has_amd,
                'hevc': has_hevc and has_amd
            }
        except:
            return {'h264': False, 'hevc': False}

    @staticmethod
    def check_vaapi():
        try:
            encoders = GPUDetector.check_encoders()
            return encoders['h264'] or encoders['hevc']
        except:
            return False

class VideoEncoder:
    def __init__(self):
        self.cpu_count = psutil.cpu_count(logical=False)
        self.gpu_detector = GPUDetector()
        self.encoders = self.gpu_detector.check_encoders()
        self.has_gpu = self.gpu_detector.check_vaapi()

    def get_cpu_params(self, high_quality=True):
        if high_quality:
            return [
                "-c:v", "libx264",
                "-preset", "slow",
                "-crf", "18",
                "-maxrate", "10M",
                "-bufsize", "20M",
                "-profile:v", "high",
                "-tune", "stillimage",
                "-movflags", "+faststart",
                "-pix_fmt", "yuv420p"
            ]
        else:
            return [
                "-c:v", "libx264",
                "-preset", "medium",
                "-crf", "23"
            ]

def obtener_numero_pista(nombre_archivo):
    match = re.search(r'^(\d+)', os.path.splitext(nombre_archivo)[0])
    if match:
        return int(match.group(1))
    match = re.search(r'(\d+)', os.path.splitext(nombre_archivo)[0])
    if match:
        return int(match.group(1))
    return nombre_archivo

def procesar_audio(archivo_path):
    try:
        return AudioFileClip(archivo_path)
    except Exception as e:
        print(f"No se pudo cargar el archivo {archivo_path}: {str(e)}")
        return None

def crear_video(directorio_audio, imagen_path, output_path, high_quality=True, force_cpu=False, add_info=print, update_progress=None):
    encoder = VideoEncoder()
    
    if encoder.has_gpu and not force_cpu:
        codec_usado = 'HEVC' if encoder.encoders['hevc'] else 'H.264'
        add_info(f"GPU AMD detectada, usando aceleración por hardware con codec {codec_usado}")
    else:
        add_info("Usando codificación por CPU")

    formatos_audio = ['.mp3', '.wav', '.ogg', '.flac', '.aac', '.m4a', '.wma']
    archivos_audio = [f for f in os.listdir(directorio_audio) if os.path.splitext(f.lower())[1] in formatos_audio]
    
    archivos_audio.sort(key=obtener_numero_pista)
    
    add_info("Orden de los archivos de audio:")
    for archivo in archivos_audio:
        add_info(f"{obtener_numero_pista(archivo)}: {archivo}")

    clips_audio = []
    for i, archivo in enumerate(archivos_audio):
        clip = procesar_audio(os.path.join(directorio_audio, archivo))
        if clip is not None:
            clips_audio.append(clip)
        add_info(f"Procesado: {archivo}")
        if update_progress:
            update_progress(i / len(archivos_audio) * 30)

    if not clips_audio:
        raise Exception("No se encontraron archivos de audio válidos")

    audio_final = concatenate_audioclips(clips_audio)

    add_info("Procesando imagen...")

    imagen_pil = Image.open(imagen_path)
    ancho_video, alto_video = 1920, 1080
    ancho_imagen, alto_imagen = imagen_pil.size
    
    escala_ancho = ancho_video / ancho_imagen
    escala_alto = alto_video / alto_imagen
    escala = min(escala_ancho, escala_alto)
    
    nuevo_ancho = int(ancho_imagen * escala)
    nuevo_alto = int(alto_imagen * escala)
    imagen_redimensionada = imagen_pil.resize((nuevo_ancho, nuevo_alto), Image.LANCZOS)
    
    x = (ancho_video - nuevo_ancho) // 2
    y = (alto_video - nuevo_alto) // 2
    
    fondo = Image.new('RGB', (ancho_video, alto_video), color='black')
    fondo.paste(imagen_redimensionada, (x, y))
    
    video = ImageClip(np.array(fondo))
    video = video.set_duration(audio_final.duration)

    video = video.fx(vfx.fadeout, duration=4)
    video = video.fx(vfx.fadein, duration=4)

    video_final = video.set_audio(audio_final)

    add_info("Configurando codificación...")
    add_info(f"Usando calidad {'alta' if high_quality else 'estándar'}")
    
    if update_progress:
        update_progress(35)

    cpu_count = psutil.cpu_count(logical=False)

    try:
        # Para GPU, usamos un enfoque diferente
        if encoder.has_gpu and not force_cpu:
            # Construir los parámetros para VAAPI
            ff_params = [
                "-hwaccel", "vaapi",
                "-hwaccel_device", "/dev/dri/renderD128",
                "-vf", "format=nv12|vaapi,hwupload",
                "-c:v", "hevc_vaapi" if encoder.encoders['hevc'] else "h264_vaapi",
                "-qp", "18" if high_quality else "23"
            ]
        else:
            # Parámetros para CPU
            ff_params = encoder.get_cpu_params(high_quality)

        add_info(f"Iniciando la generación del video...")

        redirector = StdoutRedirector(add_info, lambda p: update_progress(35 + p * 0.65) if update_progress else None)

        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = redirector
        sys.stderr = redirector

        video_final.write_videofile(
            output_path,
            fps=30,
            codec='libx264',  # El codec real se establece en los parámetros
            audio_codec='aac',
            audio_bitrate='320k',
            threads=cpu_count,
            ffmpeg_params=ff_params,
            logger='bar',
            verbose=False
        )
    except Exception as e:
        add_info(f"Error durante la codificación: {str(e)}")
        if not force_cpu and encoder.has_gpu:
            add_info("Error con GPU. Intentando con codificación por CPU...")
            try:
                cpu_params = encoder.get_cpu_params(high_quality)
                video_final.write_videofile(
                    output_path,
                    fps=30,
                    codec='libx264',
                    audio_codec='aac',
                    audio_bitrate='320k',
                    threads=cpu_count,
                    ffmpeg_params=cpu_params,
                    logger='bar',
                    verbose=False
                )
            except Exception as e2:
                raise Exception(f"Error en ambos intentos de codificación: {str(e2)}")
        else:
            raise
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
        for clip in clips_audio:
            clip.close()
        video_final.close()

    add_info("Video generado con éxito.")
    if update_progress:
        update_progress(100)

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.master.title("VideoGenerator v1.1 (Linux)")
        self.master.geometry("900x600")
        self.master.resizable(False, False)
        
        try:
            icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon.png')
            if os.path.exists(icon_path):
                icon_image = Image.open(icon_path)
                icon_photo = ImageTk.PhotoImage(icon_image)
                self.master.wm_iconphoto(True, icon_photo)
        except Exception as e:
            print(f"No se pudo cargar el icono: {e}")
        
        self.pack(fill=tk.BOTH, expand=True)
        self.high_quality = tk.BooleanVar(value=True)
        self.force_cpu = tk.BooleanVar(value=False)
        
        # Detectar GPU y codecs disponibles
        self.gpu_detector = GPUDetector()
        self.encoders = self.gpu_detector.check_encoders()
        self.has_gpu = self.gpu_detector.check_vaapi()
        
        self.create_widgets()
        
        if self.has_gpu:
            codecs = []
            if self.encoders['h264']:
                codecs.append('H.264')
            if self.encoders['hevc']:
                codecs.append('HEVC')
            self.add_info(f"GPU AMD detectada: Codecs disponibles: {', '.join(codecs)}")
        else:
            self.add_info("No se detectó GPU AMD: Se usará codificación por CPU")
            self.force_cpu.set(True)

    def create_widgets(self):
        main_frame = ttk.Frame(self)
        main_frame.pack(padx=20, pady=20, fill=tk.BOTH, expand=True)

        style = ttk.Style()
        style.configure('TButton', font=('Arial', 12))
        style.configure('Salir.TButton', 
                       font=('Arial', 12, 'bold'),
                       padding=(0, 0))

        selection_frame = ttk.Frame(main_frame)
        selection_frame.pack(fill=tk.X, pady=10)

        self.directorio_btn = ttk.Button(selection_frame, text="Seleccionar directorio de audio", 
                                       command=self.seleccionar_directorio)
        self.directorio_btn.grid(row=0, column=0, padx=5, pady=5, sticky="ew")

        self.imagen_btn = ttk.Button(selection_frame, text="Seleccionar imagen", 
                                   command=self.seleccionar_imagen)
        self.imagen_btn.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        self.salida_btn = ttk.Button(selection_frame, text="Seleccionar directorio de salida", 
                                   command=self.seleccionar_directorio_salida)
        self.salida_btn.grid(row=1, column=0, padx=5, pady=5, sticky="ew")

        self.nombre_btn = ttk.Button(selection_frame, text="Especificar nombre del archivo", 
                                   command=self.especificar_nombre_archivo)
        self.nombre_btn.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        selection_frame.grid_columnconfigure(0, weight=1)
        selection_frame.grid_columnconfigure(1, weight=1)

        # Frame para opciones de codificación
        encoding_frame = ttk.Frame(main_frame)
        encoding_frame.pack(fill=tk.X, pady=5)

        options_frame = ttk.Frame(encoding_frame)
        options_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.quality_check = ttk.Checkbutton(options_frame, 
                                           text="Alta calidad (más lento)",
                                           variable=self.high_quality)
        self.quality_check.pack(side=tk.LEFT, padx=5)

        if self.has_gpu:
            self.cpu_check = ttk.Checkbutton(options_frame, 
                                           text="Forzar uso de CPU",
                                           variable=self.force_cpu)
            self.cpu_check.pack(side=tk.LEFT, padx=5)

        self.generar_btn = ttk.Button(encoding_frame, text="Generar video", 
                                    command=self.generar_video)
        self.generar_btn.pack(side=tk.RIGHT, padx=5)

        self.progress = ttk.Progressbar(main_frame, orient="horizontal", 
                                      length=300, mode="determinate")
        self.progress.pack(fill=tk.X, pady=10)

        log_label = ttk.Label(main_frame, text="Log de progreso:", font=('Arial', 10, 'bold'))
        log_label.pack(anchor='w', pady=(10,0))

        info_frame = ttk.Frame(main_frame)
        info_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.info_text = tk.Text(info_frame, height=15, wrap=tk.WORD)
        self.info_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = ttk.Scrollbar(info_frame, orient="vertical", 
                                command=self.info_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.info_text.configure(yscrollcommand=scrollbar.set)

        # Frame para el botón SALIR
        quit_frame = ttk.Frame(main_frame)
        quit_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=0)

        self.quit = ttk.Button(quit_frame, 
                             text="SALIR",
                             style='Salir.TButton',
                             command=self.master.destroy)
        self.quit.pack(expand=True, ipadx=50, ipady=15)

    def add_info(self, message):
        self.info_text.insert(tk.END, str(message) + "\n")
        self.info_text.see(tk.END)
        self.info_text.update()

    def update_progress(self, value):
        self.progress['value'] = value
        self.progress.update()

    def seleccionar_directorio(self):
        self.directorio_audio = filedialog.askdirectory()
        if self.directorio_audio:
            self.add_info(f"Directorio de audio seleccionado: {self.directorio_audio}")

    def seleccionar_imagen(self):
        self.imagen_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.png")])
        if self.imagen_path:
            self.add_info(f"Imagen seleccionada: {self.imagen_path}")

    def seleccionar_directorio_salida(self):
        self.directorio_salida = filedialog.askdirectory()
        if self.directorio_salida:
            self.add_info(f"Directorio de salida seleccionado: {self.directorio_salida}")

    def especificar_nombre_archivo(self):
        self.nombre_archivo = simpledialog.askstring("Nombre del archivo", 
                                                   "Ingrese el nombre del archivo de video (sin extensión):")
        if self.nombre_archivo:
            self.nombre_archivo = self.nombre_archivo.strip()
            if not self.nombre_archivo.endswith('.mp4'):
                self.nombre_archivo += '.mp4'
            self.add_info(f"Nombre del archivo especificado: {self.nombre_archivo}")

    def generar_video(self):
        if not hasattr(self, 'directorio_audio') or not hasattr(self, 'imagen_path') \
           or not hasattr(self, 'directorio_salida'):
            messagebox.showerror("Error", 
                               "Por favor, selecciona el directorio de audio, la imagen y el directorio de salida")
            return

        if not hasattr(self, 'nombre_archivo'):
            self.nombre_archivo = "video_musical.mp4"

        output_path = os.path.join(self.directorio_salida, self.nombre_archivo)
        
        counter = 1
        nombre_base, extension = os.path.splitext(self.nombre_archivo)
        while os.path.exists(output_path):
            output_path = os.path.join(self.directorio_salida, f"{nombre_base}_{counter}{extension}")
            counter += 1

        self.add_info("Iniciando generación del video...")
        if self.has_gpu and not self.force_cpu.get():
            codec_usado = 'HEVC' if self.encoders['hevc'] else 'H.264'
            self.add_info(f"Usando aceleración por hardware GPU con codec {codec_usado}")
        else:
            self.add_info("Usando codificación por CPU")
            
        self.progress['value'] = 0
        
        # Deshabilitar todos los controles durante la generación
        for widget in [self.generar_btn, self.directorio_btn, self.imagen_btn, 
                      self.salida_btn, self.nombre_btn, self.quality_check, 
                      self.quit]:
            widget['state'] = 'disabled'
        if self.has_gpu:
            self.cpu_check['state'] = 'disabled'
        
        threading.Thread(target=self.generar_video_thread, 
                       args=(output_path,), daemon=True).start()

    def generar_video_thread(self, output_path):
        try:
            crear_video(self.directorio_audio, self.imagen_path, output_path,
                       self.high_quality.get(), self.force_cpu.get(),
                       self.add_info, self.update_progress)
            self.master.after(0, self.video_generado_exitosamente, output_path)
        except Exception as e:
            self.master.after(0, self.mostrar_error, str(e))
        finally:
            self.master.after(0, self.habilitar_botones)

    def video_generado_exitosamente(self, output_path):
        self.add_info(f"Video generado correctamente: {output_path}")
        messagebox.showinfo("Éxito", f"Video generado correctamente: {output_path}")

    def mostrar_error(self, mensaje_error):
        self.add_info(f"Error al generar el video: {mensaje_error}")
        messagebox.showerror("Error", f"Error al generar el video: {mensaje_error}")

    def habilitar_botones(self):
        for widget in [self.generar_btn, self.directorio_btn, self.imagen_btn, 
                      self.salida_btn, self.nombre_btn, self.quality_check, 
                      self.quit]:
            widget['state'] = 'normal'
        if self.has_gpu:
            self.cpu_check['state'] = 'normal'

if __name__ == "__main__":
    root = tk.Tk()
    app = Application(master=root)
    app.mainloop()